# Contoso Security Assessment

A cybersecurity assessment site for **Contoso Corporation**, a fictional financial-
services firm running its digital workplace on Microsoft 365. It walks through a real,
interactive demonstration of the Microsoft 365 credential-harvesting phishing attack —
how it happens, and how a security team detects, contains, and resolves it.

This version was rebuilt to be as simple as possible:

- **Zero npm dependencies.** Nothing to install, ever — pure Node.js.
- **One project, one deploy.** No separate frontend/backend, no CORS, no config file
  to edit with a backend URL.
- **Deploys to Vercel with zero configuration** — just import the repo.

## How it works

- `/api/*.js` — each file is a real backend endpoint (Vercel serverless function
  convention: a file at `api/threats.js` becomes the endpoint `/api/threats`
  automatically). Locally, `server.js` runs those exact same files.
- `/public/` — the static frontend (HTML/CSS/JS), served directly.
- `/lib/data.js` — all the data (organization, threats, vulnerabilities, attack
  simulation script, etc.) plus the in-memory "database."

Same code runs identically whether it's on your laptop or deployed on Vercel.

## Option 1 — Run it locally (no installation at all)

```bash
node server.js
```
That's it — one command, no `npm install`. Open **http://localhost:3000**.

Login: username `admin`, password `Admin@2026`, any 6-digit code (e.g. `123456`).

## Option 2 — Deploy to Vercel

1. Push this folder to a GitHub repo
2. Go to [vercel.com](https://vercel.com) → **Add New Project** → import the repo
3. Leave all settings as default (Framework Preset: **Other**) → **Deploy**

That's the whole process — no environment variables, no separate backend host, no
config file to edit. You'll get a live URL like `https://your-project.vercel.app`.

## Important honesty note about the "database"

The vulnerability-status clicks and the live activity feed genuinely write to a real
backend endpoint (`POST /api/vulnerabilities`, `POST /api/activity-log`) — this isn't
fake. But the data is stored **in memory**, not in a persistent file or SQL database:

- **Locally:** your changes stick as long as `node server.js` keeps running. Stop the
  server and restart it, and it resets to the seed data.
- **On Vercel:** changes persist while a serverless "instance" stays warm, but reset on
  a cold start (after a period of inactivity) or a new deployment.

This is genuinely how the backend behaves — a real API doing real reads and writes —
it just isn't hooked up to a permanent database. If your assignment specifically
requires a persistent database, say so and I can wire this same project up to a real
one (e.g. Vercel Postgres, or SQLite for local-only use) — it's a small change from here.

## Site sections

| Section | What it covers |
|---|---|
| Dashboard | Live severity/risk charts, totals, real-time activity feed |
| Company Profile | Intro to Microsoft, then Contoso Corporation, its Microsoft 365 services, and mobile/device risk |
| Network Architecture | Topology, protocols, devices, cloud infrastructure |
| Attack Simulation | Press Play to watch the credential-harvesting attack unfold, then the resolution timeline |
| Security Posture | Tabs: Vulnerabilities (status badges are clickable, call the real API), Application Security, Compliance |
| Recommendations | Prioritized security improvements |

## Editing the content

Everything lives in `lib/data.js` — edit the arrays there and restart `node server.js`
(or redeploy on Vercel) to change any content on the site.
