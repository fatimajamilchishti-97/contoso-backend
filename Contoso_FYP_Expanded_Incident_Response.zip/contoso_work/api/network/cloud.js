const { NETWORK_CLOUD } = require('../../lib/data');
module.exports = (req, res) => res.status(200).json(NETWORK_CLOUD);
