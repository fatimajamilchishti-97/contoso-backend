const { NETWORK_PROTOCOLS } = require('../../lib/data');
module.exports = (req, res) => res.status(200).json(NETWORK_PROTOCOLS);
