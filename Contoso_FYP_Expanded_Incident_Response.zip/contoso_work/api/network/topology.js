const { NETWORK_TOPOLOGY } = require('../../lib/data');
module.exports = (req, res) => res.status(200).json(NETWORK_TOPOLOGY);
